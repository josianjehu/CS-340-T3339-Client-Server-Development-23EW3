from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """
    
    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:47895/AAC' % (username, password))
        # where xxxx is your unique port number
        self.database = self.client['AAC']

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            if data:
                # if there is data when create is used it gets inserted
                self.database.animals.insert(data)  # data should be dictionary
                return True              
            else:
                raise Exception("Nothing to save, because data parameter is empty")
                return False 
        else:
            raise Exception("Data is None")

# Create method to implement the R in CRUD. 

    def read(self, data):
        # if there is a key to go by then print all of the books that contain that
        if data is not None: 
            #if data:
                find_result = self.database.animals.find(data, {"_id":False})
                return find_result
            #else:
                #if data is None nothing to be read
                #raise Exception("Nothing to find, because data parameter is empty")
        else:
            raise Exception("Data is None")
        
            
    def post(self, data):
        # if there is a key to go by then print all of the books that contain that
        if data is not None: 
            if data:
                count_result = self.database.animals.count_documents(data)
                return count_result
            else:
                #if data is None nothing to be read
                raise Exception("Nothing to count, because data parameter is empty")
        else:
            raise Exception("Data is None")
            
    def delete(self, data):
        if data is not None:
            if data:
                # if there is data when create is used then it can be deleted here
                delete_result = self.database.animals.delete_many(data)  # data should be dictionary
                return delete_result              
            else:
                #if data is none theres nothing to delete
                raise Exception("Nothing to delete, because data parameter is empty")
        else:
            raise Exception("Data is None")

    def update(self, data, update):
        # if there is a key to go by then print all of the books that contain that
        if data is not None: 
            if data:
                update_result = self.database.animals.update(data, update)
                return update_result
            else:
            #if data is None nothing to be read
                raise Exception("Nothing to update, because data parameter is empty")
        else:
            raise Exception("Data is None")